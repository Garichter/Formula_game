#include "../include/moving.h"

bool tecla_D = false;
bool tecla_S = false;
bool tecla_A = false;
bool tecla_W = false;

float speed = 0.0f;
float last_speed = 0.0f;

void desloca(glm::vec4& obj_pos, glm::vec4& obj_vec, float& obj_angle, float delta_t)
{
    constexpr float max_speed = 80.0f;
    float acceleration = 20.0f*(1- speed/max_speed);

    if (tecla_W) speed += acceleration*delta_t;

    if (tecla_S) {
        if(speed > 0) speed -= 30.0f*delta_t;
        else speed -= 5.0f*delta_t*(1 + speed/20.0f);
    }
    if(speed*last_speed < 0) {speed = 0.0f; tecla_W = false, tecla_S = false;}

    if (!tecla_S && !tecla_W)  {
        if(speed>0) speed -= speed * 0.1f * delta_t;
        else if(speed <0) speed -= speed * 0.1f * delta_t;
    }

    if (tecla_A)
    {
        if(fabs(speed > 20.0f)) obj_angle += 0.8*delta_t*max_speed/(max_speed+speed);
        else obj_angle += delta_t*speed/20.0f;
        obj_vec = glm::vec4(-sin(obj_angle), 0.0f, -cos(obj_angle), 0.0f);
    }
    if (tecla_D)
    {
        if(fabs(speed > 20.0f)) obj_angle -= 0.8*delta_t*max_speed/(max_speed+speed);
        else obj_angle -= delta_t*speed/20.0f;
        obj_vec = glm::vec4(-sin(obj_angle), 0.0f, -cos(obj_angle), 0.0f);
    }

    obj_pos += obj_vec*speed*delta_t;
    last_speed = speed;
}

void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mod)
{
    for (int i = 0; i < 10; ++i)
        if (key == GLFW_KEY_0 + i && action == GLFW_PRESS && mod == GLFW_MOD_SHIFT)
            std::exit(100 + i);

    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);

    if (key == GLFW_KEY_D)
    {
        if (action == GLFW_PRESS) tecla_D = true;
        else if (action == GLFW_RELEASE) tecla_D = false;
    }
    if (key == GLFW_KEY_S)
    {
        if (action == GLFW_PRESS) tecla_S = true;
        else if (action == GLFW_RELEASE) tecla_S = false;
    }
    if (key == GLFW_KEY_A)
    {
        if (action == GLFW_PRESS) tecla_A = true;
        else if (action == GLFW_RELEASE) tecla_A = false;
    }
    if (key == GLFW_KEY_W)
    {
        if (action == GLFW_PRESS) tecla_W = true;
        else if (action == GLFW_RELEASE) tecla_W = false;
    }
}
