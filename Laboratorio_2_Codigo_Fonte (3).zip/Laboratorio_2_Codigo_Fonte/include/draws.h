#ifndef _DRAWS_H
#define _DRAWS_H

#include <cmath>

#include <glad/glad.h>   // Cria��o de contexto OpenGL 3.3
#include <GLFW/glfw3.h>  // Cria��o de janelas do sistema operacional


GLuint BuildTrack();
GLuint BuildFloor();
GLuint BuildCube();
GLuint BuildTrackCircle();

#endif // _DRAWS_H
